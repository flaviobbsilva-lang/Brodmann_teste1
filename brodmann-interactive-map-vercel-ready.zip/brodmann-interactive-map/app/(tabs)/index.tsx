import { View, Text, ScrollView, Switch, Pressable, Alert, Platform } from "react-native";
import { useState, useEffect } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { ScreenContainer } from "@/components/screen-container";
import { BrainMapSVG } from "@/components/brain-map-svg";
import { GroupSelector } from "@/components/group-selector";
import { AreaDetailPanel } from "@/components/area-detail-panel";
import { TEN20_POINTS } from "@/constants/brodmann-data";
import { useColors } from "@/hooks/use-colors";

const STORAGE_KEY = "TEN20_HOTSPOTS_V1";

interface HotspotCoordinate {
  label: string;
  x: number;
  y: number;
}

/**
 * Home Screen - Mapa Interativo de Áreas de Brodmann
 * 
 * Exibe um mapa cerebral com TODOS os 15 pontos do sistema 10-20 sempre visíveis e clicáveis.
 * Permite seleção individual (clique no ponto) ou por grupo (botões de grupo).
 * Modo de edição: permite arrastar hotspots e salvar coordenadas com persistência.
 */
export default function HomeScreen() {
  const colors = useColors();
  const [selectedPoints, setSelectedPoints] = useState<string[]>([]);
  const [selectedGroupKey, setSelectedGroupKey] = useState<string | null>(null);
  const [editMode, setEditMode] = useState(false);
  const [editedCoordinates, setEditedCoordinates] = useState<Record<string, { svgX: number; svgY: number }>>({});
  const [savedCoordinates, setSavedCoordinates] = useState<Record<string, { svgX: number; svgY: number }> | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Carregar coordenadas salvas ao montar
  useEffect(() => {
    loadSavedCoordinates();
  }, []);

  const loadSavedCoordinates = async () => {
    try {
      let jsonString: string | null = null;
      
      if (Platform.OS === "web") {
        jsonString = localStorage.getItem(STORAGE_KEY);
      } else {
        jsonString = await AsyncStorage.getItem(STORAGE_KEY);
      }

      if (jsonString) {
        const hotspots: HotspotCoordinate[] = JSON.parse(jsonString);
        const coordsMap: Record<string, { svgX: number; svgY: number }> = {};
        
        hotspots.forEach(h => {
          coordsMap[h.label] = { svgX: h.x, svgY: h.y };
        });
        
        setSavedCoordinates(coordsMap);
        console.log("✅ Coordenadas carregadas do storage:", Object.keys(coordsMap).length, "pontos");
      } else {
        console.log("ℹ️ Nenhuma coordenada salva encontrada, usando padrão");
      }
    } catch (error) {
      console.error("Erro ao carregar coordenadas:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const handlePointSelect = (label: string) => {
    // Seleção individual: substitui seleção anterior
    setSelectedPoints([label]);
    setSelectedGroupKey(null);
  };

  const handleGroupSelect = (key: string, pontos: string[]) => {
    // Seleção por grupo: acende todos os pontos do grupo
    setSelectedPoints(pontos);
    setSelectedGroupKey(key);
  };

  const handleCoordinatesUpdate = (label: string, svgX: number, svgY: number) => {
    setEditedCoordinates(prev => ({
      ...prev,
      [label]: { svgX, svgY }
    }));
  };

  const handleSaveCoordinates = async () => {
    try {
      // Mesclar: savedCoordinates (storage) + editedCoordinates (sessão atual)
      const baseCoords = savedCoordinates || {};
      const finalCoords = { ...baseCoords, ...editedCoordinates };
      
      // Criar array de hotspots
      const allPoints: HotspotCoordinate[] = Object.keys(TEN20_POINTS).map(label => {
        const coords = finalCoords[label];
        const original = TEN20_POINTS[label];
        
        return {
          label,
          x: coords?.svgX ?? original.svgX,
          y: coords?.svgY ?? original.svgY
        };
      });

      const jsonString = JSON.stringify(allPoints, null, 2);
      
      // Salvar no storage
      if (Platform.OS === "web") {
        localStorage.setItem(STORAGE_KEY, jsonString);
      } else {
        await AsyncStorage.setItem(STORAGE_KEY, jsonString);
      }

      // Atualizar estado
      setSavedCoordinates(finalCoords);
      setEditedCoordinates({});
      
      console.log("✅ Coordenadas salvas com sucesso!");
      console.log(jsonString);
      
      Alert.alert(
        "✅ Salvo com sucesso",
        `${Object.keys(finalCoords).length} pontos salvos. As coordenadas serão mantidas após refresh.`,
        [{ text: "OK" }]
      );
    } catch (error) {
      console.error("Erro ao salvar coordenadas:", error);
      Alert.alert("Erro", "Não foi possível salvar as coordenadas.");
    }
  };

  const handleResetCoordinates = async () => {
    Alert.alert(
      "Resetar Coordenadas",
      "Tem certeza que deseja voltar às coordenadas padrão? Esta ação não pode ser desfeita.",
      [
        { text: "Cancelar", style: "cancel" },
        {
          text: "Resetar",
          style: "destructive",
          onPress: async () => {
            try {
              if (Platform.OS === "web") {
                localStorage.removeItem(STORAGE_KEY);
              } else {
                await AsyncStorage.removeItem(STORAGE_KEY);
              }
              
              setSavedCoordinates(null);
              setEditedCoordinates({});
              
              console.log("🔄 Coordenadas resetadas para o padrão");
              
              Alert.alert("✅ Resetado", "As coordenadas voltaram ao padrão.");
            } catch (error) {
              console.error("Erro ao resetar coordenadas:", error);
              Alert.alert("Erro", "Não foi possível resetar as coordenadas.");
            }
          }
        }
      ]
    );
  };

  // Fonte de coordenadas: editadas (sessão) > salvas (storage) > padrão (código)
  const getCurrentCoordinates = (label: string) => {
    const edited = editedCoordinates[label];
    if (edited) return edited;
    
    const saved = savedCoordinates?.[label];
    if (saved) return saved;
    
    const original = TEN20_POINTS[label];
    return { svgX: original.svgX, svgY: original.svgY };
  };

  if (isLoading) {
    return (
      <ScreenContainer>
        <View className="flex-1 items-center justify-center">
          <Text className="text-muted">Carregando...</Text>
        </View>
      </ScreenContainer>
    );
  }

  return (
    <ScreenContainer>
      <ScrollView className="flex-1">
        <View className="flex-1 gap-6 p-6">
          {/* Cabeçalho */}
          <View className="gap-2">
            <View className="flex-row items-center justify-between">
              <View className="flex-1">
                <Text className="text-2xl font-bold text-foreground">
                  Mapa Interativo – Áreas de Brodmann
                </Text>
                <Text className="text-sm text-muted">
                  {editMode 
                    ? "Arraste os pontos para ajustar posição" 
                    : "Sistema 10-20 • Clique nos pontos ou selecione um grupo"}
                </Text>
              </View>
              
              {/* Toggle Modo Edição */}
              <View className="items-end gap-1">
                <Text className="text-xs font-semibold text-muted uppercase">
                  Modo Edição
                </Text>
                <Switch
                  value={editMode}
                  onValueChange={(value) => {
                    setEditMode(value);
                    if (value) {
                      setSelectedPoints([]);
                      setSelectedGroupKey(null);
                    }
                  }}
                  trackColor={{ false: colors.border, true: colors.primary }}
                  thumbColor={editMode ? "#FFFFFF" : "#F3F4F6"}
                />
              </View>
            </View>
          </View>

          {/* Botões de ação (só aparecem em modo edição) */}
          {editMode && (
            <View className="flex-row gap-3">
              <Pressable
                onPress={handleSaveCoordinates}
                style={({ pressed }) => ({
                  flex: 1,
                  backgroundColor: colors.primary,
                  paddingVertical: 14,
                  paddingHorizontal: 16,
                  borderRadius: 12,
                  opacity: pressed ? 0.8 : 1,
                })}
              >
                <Text className="text-center text-sm font-bold text-white">
                  💾 Salvar
                </Text>
              </Pressable>
              
              <Pressable
                onPress={handleResetCoordinates}
                style={({ pressed }) => ({
                  flex: 1,
                  backgroundColor: "#EF4444",
                  paddingVertical: 14,
                  paddingHorizontal: 16,
                  borderRadius: 12,
                  opacity: pressed ? 0.8 : 1,
                })}
              >
                <Text className="text-center text-sm font-bold text-white">
                  🔄 Resetar
                </Text>
              </Pressable>
            </View>
          )}

          {/* Seletor de Grupos (oculto em modo edição) */}
          {!editMode && (
            <GroupSelector 
              selectedGroupKey={selectedGroupKey}
              onSelectGroup={handleGroupSelect}
            />
          )}

          {/* Mapa Cerebral */}
          <View className="bg-white rounded-2xl overflow-hidden border border-border shadow-sm p-4">
            <BrainMapSVG 
              selectedPoints={selectedPoints}
              onPointSelect={handlePointSelect}
              editMode={editMode}
              onCoordinatesUpdate={handleCoordinatesUpdate}
              customCoordinates={savedCoordinates}
            />
          </View>

          {/* Painel de Detalhes (oculto em modo edição) */}
          {!editMode && <AreaDetailPanel selectedPoints={selectedPoints} />}
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
