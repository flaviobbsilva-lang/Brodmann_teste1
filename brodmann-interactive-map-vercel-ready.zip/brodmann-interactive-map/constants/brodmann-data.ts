/**
 * Estrutura de dados dos pontos 10-20 com campos exatos
 * SVG viewBox: 0 0 1074 670
 */

export interface Ten20PointData {
  ponto_10_20: string;
  regiao_cortical_subjacente: string;
  areas_brodmann: string;
  funcao_principal: string;
  muito_relevante_para: string;
  svgX: number; // coordenada SVG absoluta
  svgY: number; // coordenada SVG absoluta
}

export const SVG_VIEWBOX = { width: 1074, height: 670 };

export const TEN20_POINTS: Record<string, Ten20PointData> = {
  "Fp1": {
    ponto_10_20: "Fp1",
    regiao_cortical_subjacente: "Pré-frontal orbitofrontal esquerdo",
    areas_brodmann: "BA 10 / BA 11",
    funcao_principal: "Regulação emocional, inibição",
    muito_relevante_para: "Ansiedade, dor crônica central, impulsividade",
    svgX: 129,
    svgY: 188
  },
  "Fp2": {
    ponto_10_20: "Fp2",
    regiao_cortical_subjacente: "Pré-frontal orbitofrontal direito",
    areas_brodmann: "BA 10 / BA 11",
    funcao_principal: "Emoção, tomada de decisão",
    muito_relevante_para: "Transtornos afetivos, descontrole emocional",
    svgX: 150,
    svgY: 241
  },
  "F3": {
    ponto_10_20: "F3",
    regiao_cortical_subjacente: "DLPFC esquerdo",
    areas_brodmann: "BA 9 / BA 46",
    funcao_principal: "Funções executivas, humor",
    muito_relevante_para: "Depressão, dor crônica, fibromialgia",
    svgX: 279,
    svgY: 188
  },
  "F4": {
    ponto_10_20: "F4",
    regiao_cortical_subjacente: "DLPFC direito",
    areas_brodmann: "BA 9 / BA 46",
    funcao_principal: "Atenção, controle emocional",
    muito_relevante_para: "Ansiedade, impulsividade, dor",
    svgX: 301,
    svgY: 241
  },
  "Área de Broca": {
    ponto_10_20: "Área de Broca",
    regiao_cortical_subjacente: "Giro frontal inferior esquerdo",
    areas_brodmann: "BA 44 / BA 45",
    funcao_principal: "Produção da fala",
    muito_relevante_para: "Afasia motora, AVC frontal",
    svgX: 322,
    svgY: 308
  },
  "C3": {
    ponto_10_20: "C3",
    regiao_cortical_subjacente: "Córtex motor primário esquerdo (M1)",
    areas_brodmann: "BA 4",
    funcao_principal: "Movimento voluntário",
    muito_relevante_para: "AVC, dor neuropática, Parkinson",
    svgX: 473,
    svgY: 188
  },
  "C4": {
    ponto_10_20: "C4",
    regiao_cortical_subjacente: "Córtex motor primário direito (M1)",
    areas_brodmann: "BA 4",
    funcao_principal: "Movimento voluntário",
    muito_relevante_para: "AVC, espasticidade, dor",
    svgX: 494,
    svgY: 241
  },
  "Cz": {
    ponto_10_20: "Cz",
    regiao_cortical_subjacente: "Região medial motora (M1/SMA)",
    areas_brodmann: "BA 4 + BA 6",
    funcao_principal: "Controle axial e marcha",
    muito_relevante_para: "Marcha, tronco, AVC bilateral",
    svgX: 516,
    svgY: 214
  },
  "SM1": {
    ponto_10_20: "SM1",
    regiao_cortical_subjacente: "Área sensório-motora primária",
    areas_brodmann: "BA 4 + BA 3,1,2",
    funcao_principal: "Integração motor-sensorial",
    muito_relevante_para: "Dor neuropática, AVC, reabilitação",
    svgX: 537,
    svgY: 201
  },
  "T3 (T7)": {
    ponto_10_20: "T3 (T7)",
    regiao_cortical_subjacente: "Temporal anterior esquerdo",
    areas_brodmann: "BA 21 / BA 22 / BA 38",
    funcao_principal: "Linguagem, memória verbal",
    muito_relevante_para: "Afasia, epilepsia, dor",
    svgX: 387,
    svgY: 348
  },
  "T4 (T8)": {
    ponto_10_20: "T4 (T8)",
    regiao_cortical_subjacente: "Temporal anterior direito",
    areas_brodmann: "BA 21 / BA 22 / BA 38",
    funcao_principal: "Emoção, prosódia",
    muito_relevante_para: "Ansiedade, dor emocional",
    svgX: 601,
    svgY: 348
  },
  "Área de Wernicke": {
    ponto_10_20: "Área de Wernicke",
    regiao_cortical_subjacente: "Temporal superior posterior esquerdo",
    areas_brodmann: "BA 22",
    funcao_principal: "Compreensão da linguagem",
    muito_relevante_para: "Afasia sensorial, AVC",
    svgX: 644,
    svgY: 295
  },
  "O1": {
    ponto_10_20: "O1",
    regiao_cortical_subjacente: "Occipital esquerdo",
    areas_brodmann: "BA 17 / BA 18 / BA 19",
    funcao_principal: "Processamento visual",
    muito_relevante_para: "Enxaqueca, AVC occipital",
    svgX: 838,
    svgY: 241
  },
  "O2": {
    ponto_10_20: "O2",
    regiao_cortical_subjacente: "Occipital direito",
    areas_brodmann: "BA 17 / BA 18 / BA 19",
    funcao_principal: "Processamento visual",
    muito_relevante_para: "Dor com componente visual",
    svgX: 859,
    svgY: 295
  },
  "Oz": {
    ponto_10_20: "Oz",
    regiao_cortical_subjacente: "Visual primário medial",
    areas_brodmann: "BA 17",
    funcao_principal: "Visão primária",
    muito_relevante_para: "Enxaqueca, integração sensorial",
    svgX: 881,
    svgY: 268
  }
};

export interface BrodmannGroup {
  key: string;
  name: string;
  pontos: string[];
}

export const BRODMANN_GROUPS: BrodmannGroup[] = [
  {
    key: "PREFRONTAL",
    name: "PREFRONTAL (Fp)",
    pontos: ["Fp1", "Fp2"]
  },
  {
    key: "DLPFC",
    name: "DLPFC (F3/F4)",
    pontos: ["F3", "F4"]
  },
  {
    key: "BROCA",
    name: "BROCA",
    pontos: ["Área de Broca"]
  },
  {
    key: "M1",
    name: "M1 (C3/C4)",
    pontos: ["C3", "C4"]
  },
  {
    key: "CZ",
    name: "Cz (M1/SMA)",
    pontos: ["Cz"]
  },
  {
    key: "SM1",
    name: "SM1",
    pontos: ["SM1"]
  },
  {
    key: "TEMPORAL",
    name: "TEMPORAL (T3/T4)",
    pontos: ["T3 (T7)", "T4 (T8)"]
  },
  {
    key: "WERNICKE",
    name: "WERNICKE",
    pontos: ["Área de Wernicke"]
  },
  {
    key: "VISUAL",
    name: "VISUAL (O1/O2/Oz)",
    pontos: ["O1", "O2", "Oz"]
  }
];
