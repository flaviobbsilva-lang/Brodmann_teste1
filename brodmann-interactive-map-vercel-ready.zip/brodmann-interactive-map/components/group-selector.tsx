import { View, Text, Pressable, ScrollView } from "react-native";
import { BRODMANN_GROUPS } from "@/constants/brodmann-data";
import { useColors } from "@/hooks/use-colors";

interface GroupSelectorProps {
  selectedGroupKey: string | null;
  onSelectGroup: (key: string, pontos: string[]) => void;
}

export function GroupSelector({ selectedGroupKey, onSelectGroup }: GroupSelectorProps) {
  const colors = useColors();

  return (
    <View className="gap-3">
      <Text className="text-sm font-semibold text-muted uppercase tracking-wide">
        Selecione um Grupo de Áreas
      </Text>
      <ScrollView 
        horizontal 
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={{ gap: 8 }}
      >
        {BRODMANN_GROUPS.map((group) => {
          const isSelected = selectedGroupKey === group.key;
          
          return (
            <Pressable
              key={group.key}
              onPress={() => onSelectGroup(group.key, group.pontos)}
              style={({ pressed }) => ({
                backgroundColor: isSelected 
                  ? colors.primary 
                  : pressed 
                  ? colors.surface 
                  : "transparent",
                borderWidth: 1,
                borderColor: isSelected ? colors.primary : colors.border,
                paddingHorizontal: 16,
                paddingVertical: 10,
                borderRadius: 12,
                opacity: pressed ? 0.7 : 1,
              })}
            >
              <Text 
                style={{ 
                  color: isSelected ? "#FFFFFF" : colors.foreground,
                  fontSize: 14,
                  fontWeight: isSelected ? "700" : "600",
                }}
              >
                {group.name}
              </Text>
            </Pressable>
          );
        })}
      </ScrollView>
    </View>
  );
}
