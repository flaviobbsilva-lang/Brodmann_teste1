import { View, Pressable, Platform, StyleSheet, Alert } from "react-native";
import { useState } from "react";
import Svg, { Image as SvgImage, Circle, Text as SvgText, G } from "react-native-svg";
import { Gesture, GestureDetector } from "react-native-gesture-handler";
import * as Haptics from "expo-haptics";
import { TEN20_POINTS, SVG_VIEWBOX } from "@/constants/brodmann-data";
import { useColors } from "@/hooks/use-colors";

interface BrainMapSVGProps {
  selectedPoints: string[]; // Lista de labels selecionados
  onPointSelect: (label: string) => void;
  editMode: boolean; // Modo de edi\u00e7\u00e3o ativo
  onCoordinatesUpdate?: (label: string, svgX: number, svgY: number) => void;
  customCoordinates?: Record<string, { svgX: number; svgY: number }> | null; // Coordenadas salvas do storage
}

export function BrainMapSVG({ 
  selectedPoints, 
  onPointSelect, 
  editMode,
  onCoordinatesUpdate,
  customCoordinates 
}: BrainMapSVGProps) {
  const colors = useColors();
  const [containerWidth, setContainerWidth] = useState(0);
  const [draggedPositions, setDraggedPositions] = useState<Record<string, { svgX: number; svgY: number }>>({});
  
  // Calcular altura mantendo aspect ratio
  const aspectRatio = SVG_VIEWBOX.height / SVG_VIEWBOX.width;
  const svgHeight = containerWidth > 0 ? containerWidth * aspectRatio : 400;
  const scale = containerWidth / SVG_VIEWBOX.width;

  const handlePointPress = (label: string) => {
    if (editMode) return; // Não seleciona em modo edição
    
    if (Platform.OS !== "web") {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
    onPointSelect(label);
  };

  const createDragGesture = (label: string, initialX: number, initialY: number) => {
    let finalX = initialX;
    let finalY = initialY;
    
    return Gesture.Pan()
      .onUpdate((event) => {
        // Converter transla\u00e7\u00e3o de pixels para coordenadas SVG
        const newSvgX = Math.round(initialX + event.translationX / scale);
        const newSvgY = Math.round(initialY + event.translationY / scale);
        
        // Limitar dentro do viewBox
        finalX = Math.max(0, Math.min(SVG_VIEWBOX.width, newSvgX));
        finalY = Math.max(0, Math.min(SVG_VIEWBOX.height, newSvgY));
        
        setDraggedPositions(prev => ({
          ...prev,
          [label]: { svgX: finalX, svgY: finalY }
        }));
      })
      .onEnd(() => {
        // Usar as coordenadas finais capturadas
        if (onCoordinatesUpdate) {
          onCoordinatesUpdate(label, finalX, finalY);
        }
        
        if (Platform.OS !== "web") {
          Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
        }
      })
      .runOnJS(true);
  };

  const allPoints = Object.values(TEN20_POINTS);
  const hotspotRadius = Platform.OS === "web" ? 25 : 18;
  const fontSize = Platform.OS === "web" ? 14 : 11;

  return (
    <View 
      style={styles.container}
      onLayout={(event) => {
        const { width } = event.nativeEvent.layout;
        setContainerWidth(width);
      }}
    >
      {containerWidth > 0 && (
        <Svg
          width="100%"
          height={svgHeight}
          viewBox={`0 0 ${SVG_VIEWBOX.width} ${SVG_VIEWBOX.height}`}
          preserveAspectRatio="xMidYMid meet"
        >
          {/* Imagem de fundo */}
          <SvgImage
            x="0"
            y="0"
            width={SVG_VIEWBOX.width}
            height={SVG_VIEWBOX.height}
            href={require("@/assets/images/tens20.png")}
            preserveAspectRatio="xMidYMid meet"
          />

          {/* Hotspots */}
          {allPoints.map((point, index) => {
            const isActive = selectedPoints.includes(point.ponto_10_20);
            // Prioridade: arrastado (sessão) > customCoordinates (storage) > padrão (código)
            const currentPos = draggedPositions[point.ponto_10_20] 
              || customCoordinates?.[point.ponto_10_20] 
              || { svgX: point.svgX, svgY: point.svgY };
            
            const hotspotContent = (
              <G key={index}>
                {/* Área clicável invisível maior para facilitar clique */}
                {!editMode && (
                  <Circle
                    cx={currentPos.svgX}
                    cy={currentPos.svgY}
                    r={hotspotRadius + 10}
                    fill="transparent"
                    onPress={() => handlePointPress(point.ponto_10_20)}
                  />
                )}
                
                {/* Círculo visível do hotspot */}
                <Circle
                  cx={currentPos.svgX}
                  cy={currentPos.svgY}
                  r={hotspotRadius}
                  fill={editMode ? "#60A5FA" : (isActive ? "#FDE047" : "rgba(156, 163, 175, 0.4)")}
                  stroke={editMode ? "#3B82F6" : (isActive ? "#FACC15" : colors.border)}
                  strokeWidth={editMode ? 4 : (isActive ? 3 : 2)}
                  onPress={editMode ? undefined : () => handlePointPress(point.ponto_10_20)}
                />
                
                {/* Label do ponto */}
                <SvgText
                  x={currentPos.svgX}
                  y={currentPos.svgY + fontSize / 3}
                  fontSize={fontSize}
                  fontWeight={editMode ? "700" : (isActive ? "700" : "600")}
                  fill={editMode ? "#1E40AF" : (isActive ? "#854D0E" : colors.muted)}
                  textAnchor="middle"
                  onPress={editMode ? undefined : () => handlePointPress(point.ponto_10_20)}
                >
                  {point.ponto_10_20}
                </SvgText>
                
                {/* Coordenadas em modo edição */}
                {editMode && (
                  <SvgText
                    x={currentPos.svgX}
                    y={currentPos.svgY + hotspotRadius + 18}
                    fontSize={10}
                    fontWeight="600"
                    fill="#1E40AF"
                    textAnchor="middle"
                  >
                    ({currentPos.svgX}, {currentPos.svgY})
                  </SvgText>
                )}
              </G>
            );

            // Envolver em GestureDetector apenas em modo edição
            if (editMode) {
              const gesture = createDragGesture(point.ponto_10_20, currentPos.svgX, currentPos.svgY);
              return (
                <GestureDetector key={index} gesture={gesture}>
                  {hotspotContent}
                </GestureDetector>
              );
            }

            return hotspotContent;
          })}
        </Svg>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    width: "100%",
  },
});
