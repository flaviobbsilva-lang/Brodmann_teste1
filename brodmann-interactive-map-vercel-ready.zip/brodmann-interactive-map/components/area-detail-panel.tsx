import { View, Text, ScrollView } from "react-native";
import { TEN20_POINTS } from "@/constants/brodmann-data";

interface AreaDetailPanelProps {
  selectedPoints: string[]; // Lista de labels selecionados
}

export function AreaDetailPanel({ selectedPoints }: AreaDetailPanelProps) {
  if (selectedPoints.length === 0) {
    return (
      <View className="p-6 bg-surface rounded-xl border border-border">
        <Text className="text-base text-muted text-center">
          Clique em um ponto no mapa ou selecione um grupo para ver os detalhes
        </Text>
      </View>
    );
  }

  return (
    <ScrollView className="max-h-[600px]">
      <View className="gap-4">
        {/* Header se múltiplos pontos */}
        {selectedPoints.length > 1 && (
          <View className="p-4 bg-primary/10 rounded-xl border border-primary/30">
            <Text className="text-sm font-semibold text-primary">
              Pontos selecionados: {selectedPoints.join(", ")}
            </Text>
          </View>
        )}

        {/* Renderizar card para cada ponto selecionado */}
        {selectedPoints.map((label, index) => {
          const pointData = TEN20_POINTS[label];
          
          if (!pointData) {
            return (
              <View key={index} className="p-6 bg-surface rounded-xl border border-border">
                <Text className="text-base text-error text-center">
                  Ponto "{label}" não encontrado
                </Text>
              </View>
            );
          }

          return (
            <View key={index} className="gap-4 p-6 bg-surface rounded-xl border border-border">
              {/* Cabeçalho */}
              <View className="gap-1">
                <Text className="text-xs font-semibold text-primary uppercase tracking-wide">
                  {pointData.areas_brodmann}
                </Text>
                <Text className="text-2xl font-bold text-foreground">
                  {pointData.ponto_10_20}
                </Text>
              </View>

              {/* Região Cortical Subjacente */}
              <View className="gap-2">
                <Text className="text-xs font-semibold text-muted uppercase tracking-wide">
                  Região cortical subjacente
                </Text>
                <Text className="text-sm text-foreground leading-relaxed">
                  {pointData.regiao_cortical_subjacente}
                </Text>
              </View>

              {/* Área(s) de Brodmann */}
              <View className="gap-2">
                <Text className="text-xs font-semibold text-muted uppercase tracking-wide">
                  Área(s) de Brodmann
                </Text>
                <View 
                  className="px-3 py-2 rounded-lg inline-flex self-start"
                  style={{ 
                    backgroundColor: "#FDE047",
                    borderWidth: 1, 
                    borderColor: "#FACC15" 
                  }}
                >
                  <Text className="text-sm font-semibold" style={{ color: "#854D0E" }}>
                    {pointData.areas_brodmann}
                  </Text>
                </View>
              </View>

              {/* Função Principal */}
              <View className="gap-2">
                <Text className="text-xs font-semibold text-muted uppercase tracking-wide">
                  Função principal
                </Text>
                <Text className="text-sm text-foreground leading-relaxed">
                  {pointData.funcao_principal}
                </Text>
              </View>

              {/* Muito Relevante Para */}
              <View className="gap-2">
                <Text className="text-xs font-semibold text-muted uppercase tracking-wide">
                  Muito relevante para
                </Text>
                <Text className="text-sm text-foreground leading-relaxed font-medium">
                  {pointData.muito_relevante_para}
                </Text>
              </View>
            </View>
          );
        })}
      </View>
    </ScrollView>
  );
}
