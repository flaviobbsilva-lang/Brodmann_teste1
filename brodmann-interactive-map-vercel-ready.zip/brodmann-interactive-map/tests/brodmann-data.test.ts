import { describe, it, expect } from "vitest";
import { TEN20_POINTS, BRODMANN_GROUPS, SVG_VIEWBOX } from "@/constants/brodmann-data";

describe("Brodmann Data", () => {
  describe("TEN20_POINTS", () => {
    it("deve conter exatamente 15 pontos", () => {
      const pointsArray = Object.values(TEN20_POINTS);
      expect(pointsArray).toHaveLength(15);
    });

    it("cada ponto deve ter todos os 7 campos obrigatórios", () => {
      Object.values(TEN20_POINTS).forEach(point => {
        expect(point).toHaveProperty("ponto_10_20");
        expect(point).toHaveProperty("regiao_cortical_subjacente");
        expect(point).toHaveProperty("areas_brodmann");
        expect(point).toHaveProperty("funcao_principal");
        expect(point).toHaveProperty("muito_relevante_para");
        expect(point).toHaveProperty("svgX");
        expect(point).toHaveProperty("svgY");
        
        expect(typeof point.ponto_10_20).toBe("string");
        expect(typeof point.regiao_cortical_subjacente).toBe("string");
        expect(typeof point.areas_brodmann).toBe("string");
        expect(typeof point.funcao_principal).toBe("string");
        expect(typeof point.muito_relevante_para).toBe("string");
        expect(typeof point.svgX).toBe("number");
        expect(typeof point.svgY).toBe("number");
        
        // Coordenadas SVG devem estar dentro do viewBox
        expect(point.svgX).toBeGreaterThanOrEqual(0);
        expect(point.svgX).toBeLessThanOrEqual(1074);
        expect(point.svgY).toBeGreaterThanOrEqual(0);
        expect(point.svgY).toBeLessThanOrEqual(670);
      });
    });

    it("deve incluir todos os pontos obrigatórios", () => {
      const labels = Object.keys(TEN20_POINTS);
      
      const requiredPoints = [
        "Fp1", "Fp2", "F3", "F4", "Área de Broca",
        "C3", "C4", "Cz", "SM1", "T3 (T7)", "T4 (T8)",
        "Área de Wernicke", "O1", "O2", "Oz"
      ];
      
      requiredPoints.forEach(point => {
        expect(labels).toContain(point);
      });
    });

    it("Fp1 deve ter dados corretos", () => {
      const fp1 = TEN20_POINTS["Fp1"];
      
      expect(fp1.ponto_10_20).toBe("Fp1");
      expect(fp1.areas_brodmann).toBe("BA 10 / BA 11");
      expect(fp1.regiao_cortical_subjacente).toContain("Pré-frontal");
      expect(fp1.funcao_principal).toContain("Regulação emocional");
      expect(fp1.muito_relevante_para).toContain("Ansiedade");
    });

    it("F3 deve ter dados de DLPFC", () => {
      const f3 = TEN20_POINTS["F3"];
      
      expect(f3.ponto_10_20).toBe("F3");
      expect(f3.areas_brodmann).toBe("BA 9 / BA 46");
      expect(f3.regiao_cortical_subjacente).toContain("DLPFC");
      expect(f3.funcao_principal).toContain("executivas");
      expect(f3.muito_relevante_para).toContain("Depressão");
    });

    it("Área de Broca deve ter dados corretos", () => {
      const broca = TEN20_POINTS["Área de Broca"];
      
      expect(broca.ponto_10_20).toBe("Área de Broca");
      expect(broca.areas_brodmann).toBe("BA 44 / BA 45");
      expect(broca.funcao_principal).toContain("fala");
      expect(broca.muito_relevante_para).toContain("Afasia");
    });
  });

  describe("BRODMANN_GROUPS", () => {
    it("deve conter 9 grupos", () => {
      expect(BRODMANN_GROUPS).toHaveLength(9);
    });

    it("cada grupo deve ter estrutura correta", () => {
      BRODMANN_GROUPS.forEach(group => {
        expect(group).toHaveProperty("key");
        expect(group).toHaveProperty("name");
        expect(group).toHaveProperty("pontos");
        
        expect(typeof group.key).toBe("string");
        expect(typeof group.name).toBe("string");
        expect(Array.isArray(group.pontos)).toBe(true);
        expect(group.pontos.length).toBeGreaterThan(0);
      });
    });

    it("todos os pontos dos grupos devem existir em TEN20_POINTS", () => {
      const allLabels = Object.keys(TEN20_POINTS);
      
      BRODMANN_GROUPS.forEach(group => {
        group.pontos.forEach(ponto => {
          expect(allLabels).toContain(ponto);
        });
      });
    });

    it("grupo VISUAL deve conter O1, O2 e Oz", () => {
      const visualGroup = BRODMANN_GROUPS.find(g => g.key === "VISUAL");
      
      expect(visualGroup).toBeDefined();
      expect(visualGroup?.pontos).toContain("O1");
      expect(visualGroup?.pontos).toContain("O2");
      expect(visualGroup?.pontos).toContain("Oz");
    });
  });

  describe("SVG_VIEWBOX", () => {
    it("deve ter dimens\u00f5es corretas", () => {
      expect(SVG_VIEWBOX.width).toBe(1074);
      expect(SVG_VIEWBOX.height).toBe(670);
    });
  });
});
